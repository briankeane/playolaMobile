var enviromnent = {
  twitterConsumerKey: 'BFSZQXz3iFJg4uLVYNxiuAFMq',
  twitterSecret: 'AbGmcsLtH3CBcMTN8fVdWtJO1awLJjS1aRnwdG9vfqMgEK5lvG'
}

$localStorage.environment = environment;
$localStorage.test = 'test';