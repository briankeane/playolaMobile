angular.module('starter.controllers')

.service('StationPlayer', function (StationsSvc, $rootScope) {

  var initialize = function(attrs) {
    this.musicStarted = false;
    this.stationId = attrs.listenStationid;
    this.audioQueue = attrs.audioQueue;
    this.muted = false;
    this.volumeLevel = 1.0;
    this.self = this;
    startPlayer();
  }

  this.restart = function (attrs) {
    initialize(attrs);
  };

  function startPlayer() {
    var song = StationsSvc.downloadSong(audioQueue[0], function(entry) {
      alert('in downloadSong callback');
      var song = new Media((cordova.file.dataDirectory + audioQueue[0].filename).replace('file://',''), onSuccess, onError);
      song.play({ playAudioWhenScreenIsLocked : false });
    });
  }

  function onSuccess() {
    self.audioQueue[0].artist = 'success';
  }

  function onError(error) {
    self.audioQueue[0].artist =  error.code + '\n' +
           'message: ' + error.message + '\n';
  }
})