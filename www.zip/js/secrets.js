angular.module('starter.controllers')
.constant('myAppConfig', {
    oauthSettings: {
        consumerKey: 'BFSZQXz3iFJg4uLVYNxiuAFMq',
        consumerSecret: 'AbGmcsLtH3CBcMTN8fVdWtJO1awLJjS1aRnwdG9vfqMgEK5lvG',
        requestTokenUrl: 'https://api.twitter.com/oauth/request_token',
        authorizationUrl: "https://api.twitter.com/oauth/authorize",
        accessTokenUrl: "https://api.twitter.com/oauth/access_token",
        callbackUrl: "http://localhost/callback"
    }
});